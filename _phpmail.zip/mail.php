<?php
// Pastikan PHPMailer sudah di-include
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php'; // Jika menggunakan Composer

function sendEmailNotification($toEmail, $toName, $subject, $body) {
    $mail = new PHPMailer(true);

    try {
        // Set konfigurasi server SMTP
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'pantai.batubesar@gmail.com'; // Ganti dengan email Gmail Anda
        $mail->Password = 'Ayamkampung1$'; // Ganti dengan password Gmail Anda
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        // Set email pengirim dan penerima
        $mail->setFrom('pantai.batubesar@gmail.com', 'Intrust Notifikasi');
        $mail->addAddress($toEmail, $toName);

        // Set konten email
        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body = $body;

        // Kirim email
        $mail->send();
        echo "Email berhasil dikirim ke $toEmail";
    } catch (Exception $e) {
        echo "Gagal mengirim email. Error: {$mail->ErrorInfo}";
    }
}

$post_email = $_GET['emailTo'];
$nama = $_GET['nama'];
$subject = $_GET['subject'];
$body = $_GET['body'];

// Contoh pemanggilan fungsi
sendEmailNotification($post_email, $nama, $subject, $body);
