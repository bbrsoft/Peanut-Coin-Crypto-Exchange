<?php
/*
	CoinPayments.net API Example
	Copyright 2014 CoinPayments.net. All rights reserved.	
	License: GPLv2 - http://www.gnu.org/licenses/gpl-2.0.txt
*/
	require('./coinpayments.inc.php');
	$cps = new CoinPaymentsAPI();
	$cps->Setup('2c720bf3eb175c9Eb3a7598875E333494499E6Ba8Fef257A6431e2fbed3FE903', 'b26f87d62f54652f15e4ea61eb2322ad2215435ac0fa46d90550dbebd560e847');

	$result = $cps->GetBalances();
	if ($result['error'] == 'ok') {
		print 'Coins returned: '.count($result['result'])."\n";
		$le = php_sapi_name() == 'cli' ? "\n" : '<br />';
		foreach ($result['result'] as $coin => $bal) {
			print $coin.': '.sprintf('%.08f', $bal['balancef']).$le;
		}
	} else {
		print 'Error: '.$result['error']."\n";
	}
