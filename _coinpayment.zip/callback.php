<?php
// Hubungkan dengan database
include('../_koneksi.php');

// Verifikasi HMAC
$request = file_get_contents('php://input');
$hmac = hash_hmac("sha512", $request, $secret_ipn);

if (!hash_equals($hmac, $_SERVER['HTTP_HMAC'])) {
    die("HMAC not matching");
}

// Ambil informasi transaksi
$txn_id = $_POST['txn_id'];
$amount = $_POST['amount1'];
$status = intval($_POST['status']);
$currency = $_POST['currency1'];

// Update status transaksi di tabel `crypto` berdasarkan `txn_id`
if ($status >= 100 || $status == 2) {
    // Status 100 atau 2 menunjukkan pembayaran sukses
    $sql = "UPDATE crypto SET status = 'Completed' WHERE txn_id = '$txn_id'";
} else if ($status < 0) {
    // Status negatif menunjukkan kegagalan
    $sql = "UPDATE crypto SET status = 'Failed' WHERE txn_id = '$txn_id'";
} else {
    // Status selain itu masih pending
    $sql = "UPDATE crypto SET status = 'Pending' WHERE txn_id = '$txn_id'";
}

if ($conn->query($sql) === TRUE) {
    echo "Callback diproses, status diperbarui.";
} else {
    echo "Error: " . $conn->error;
}

$conn->close();

// URL tujuan
$url = 'https://intrust.live/phpmail/mail.php';

// Data yang akan dikirim
$data = [
    'emailTo' => 'user@example.com',  // Alamat email penerima
    'nama' => 'Nama Penerima',         // Nama penerima
    'subject' => 'Subject Email',      // Subjek email
    'body' => 'Isi dari email ini.',   // Konten email
];

// Inisialisasi cURL
$ch = curl_init($url);

// Set opsi cURL
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

// Eksekusi cURL dan simpan respons
$response = curl_exec($ch);

// Periksa apakah ada error pada cURL
if ($response === false) {
    echo 'Error cURL: ' . curl_error($ch);
} else {
    echo 'Response dari server: ' . $response;
}

?>
