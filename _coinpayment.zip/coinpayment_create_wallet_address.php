<?php
function createWalletAddress($currency) {
    $public_key = 'b26f87d62f54652f15e4ea61eb2322ad2215435ac0fa46d90550dbebd560e847';
    $private_key = '2c720bf3eb175c9Eb3a7598875E333494499E6Ba8Fef257A6431e2fbed3FE903';
    
     // Setup parameter
    $params = [
        'version' => 1,
        'cmd' => 'get_callback_address',
        'key' => $public_key,
        'format' => 'json',
        'currency' => $currency,
    ];

    // Generate HMAC signature
    $hmac = hash_hmac('sha512', http_build_query($params), $private_key);

    // Initialize cURL
    $ch = curl_init('https://www.coinpayments.net/api.php');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($params)); // Ensure POST data is sent in x-www-form-urlencoded format
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['HMAC: ' . $hmac]);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // Ignore SSL verification for testing purposes
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);

    // Execute the request
    $response = curl_exec($ch);

    // Error handling
    if ($response === false) {
        return 'cURL Error: ' . curl_error($ch);
    }
    
    curl_close($ch);

    // Decode JSON response
    $result = json_decode($response, true);

    if ($result['error'] == 'ok') {
        // Address successfully created
        return $result['result']['address'];
    } else {
        // Handle error
        return 'Error: ' . $result['error'];
    }
}

// Contoh penggunaan
$coin = $_GET['coin'];
$address = createWalletAddress($coin);
echo $address;
