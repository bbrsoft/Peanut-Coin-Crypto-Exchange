<?php
/*
	CoinPayments.net API Example
	Copyright 2014 CoinPayments.net. All rights reserved.	
	License: GPLv2 - http://www.gnu.org/licenses/gpl-2.0.txt
*/
	require('./coinpayments.inc.php');
	$cps = new CoinPaymentsAPI();
	$cps->Setup('2c720bf3eb175c9Eb3a7598875E333494499E6Ba8Fef257A6431e2fbed3FE903', 'b26f87d62f54652f15e4ea61eb2322ad2215435ac0fa46d90550dbebd560e847');

	$result = $cps->GetRates();
	if ($result['error'] == 'ok') {
		print 'Number of currencies: '.count($result['result'])."\n";
		foreach ($result['result'] as $coin => $rate) {
			if (php_sapi_name() == 'cli') {
				print print_r($rate);
			} else {
				print nl2br(print_r($rate, TRUE));
			}
		}
	} else {
		print 'Error: '.$result['error']."\n";
	}
